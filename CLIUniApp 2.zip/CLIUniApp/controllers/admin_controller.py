
from utils.printer import print_prompt, print_success, print_error, print_notice
from models.database import Database
from models.student import Student

class AdminController:
    def show_menu(self):
        while True:
            print()
            print_prompt("Admin System (c/g/p/r/s/x): "), 
            choice = input().strip().lower()

            if choice == "s":
                self.show_all_students()
            elif choice == "g":
                self.group_by_grade()
            elif choice == "p":
                self.partition_pass_fail()
            elif choice == "r":
                self.remove_student()
            elif choice == "c":
                self.clear_database()
            elif choice == "x":
                break
            else:
                print_error("Invalid input. Please enter one of: c, g, p, r, s, x")

    def show_all_students(self):
        print_success("\nStudent List")
        students = Database.load_students()
        if not students:
            print_notice("No students in the database.")
            return

        for student in students:
            print(student)

    def group_by_grade(self):
        print_success("\nGrade Grouping")
        students = Database.load_students()
        if not students:
            print_notice("No students to group.")
            return

        groups = {}
        for student in students:
            for subject in student.subjects:
                grade = subject.grade
                if grade not in groups:
                    groups[grade] = []
                groups[grade].append((student.name, student.id, grade, subject.mark))

        for grade, records in groups.items():
            print_notice(f"{grade} -->")
            for name, sid, grade, mark in records:
                print(f"{name} :: {sid} --> GRADE:  {grade} - MARK: {mark:.2f}")

    def partition_pass_fail(self):
        print_success("\nPASS/FAIL Partition")
        students = Database.load_students()
        passed = []
        failed = []

        for s in students:
            if s.is_pass():
                passed.append(s)
            else:
                failed.append(s)

        print_notice("PASS -->")
        for s in passed:
            print(f"{s.name} :: {s.id} --> GRADE: {s.subjects[0].grade} - MARK: {s.average_mark():.2f}" if s.subjects else f"{s.name} :: {s.id} (No subjects)")

        print_notice("\nFAIL -->")
        for s in failed:
            print(f"{s.name} :: {s.id} --> GRADE: {s.subjects[0].grade} - MARK: {s.average_mark():.2f}" if s.subjects else f"{s.name} :: {s.id} (No subjects)")

    def remove_student(self):
        student_id = input("Remove by ID: ").strip()
        success = Database.delete_student_by_id(student_id)
        if success:
            print_notice(f"Student {student_id} removed successfully")
        else:
            print_error(f"Student {student_id} does not exist")

    def clear_database(self):
        confirm = input("Are you sure you want to clear the database (Y)ES/(N)O: ").strip().lower()
        if confirm == "y":
            Database.clear_all()
            print_notice("Students data cleared")
        else:
            print_notice("Operation cancelled")
