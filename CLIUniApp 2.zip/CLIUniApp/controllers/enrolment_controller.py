

from utils.printer import print_prompt, print_success, print_error, print_notice
from models.database import Database

class EnrolmentController:
    def __init__(self, student):
        self.student = student

    def show_menu(self):
        while True:
            print()
            print_prompt("Student Course Menu (c/e/r/s/x): "), 
            choice = input().strip().lower()

            if choice == "c":
                self.change_password()
            elif choice == "e":
                self.enrol_subject()
            elif choice == "r":
                self.remove_subject()
            elif choice == "s":
                self.show_subjects()
            elif choice == "x":
                break
            else:
                print_error("Invalid input. Please enter one of: c, e, r, s, x")

    def change_password(self):
        print_notice("\nUpdating Password")
        new_pwd = input("New Password: ").strip()
        confirm_pwd = input("Confirm Password: ").strip()

        if new_pwd != confirm_pwd:
            print_error("Password does not match - try again")
            return

        self.student.change_password(new_pwd)
        self.save_student()
        print_success("Password updated successfully")

    def enrol_subject(self):
        if len(self.student.subjects) >= 4:
            print_error("Students are allowed to enrol in 4 subjects only")
            return

        subject = self.student.enrol_subject()
        print_success(f"\nEnrolling in Subject-{subject.subject_id}")
        print_notice(f"You are now enrolled in {len(self.student.subjects)} out of 4 subjects")
        self.save_student()

    def remove_subject(self):
        subject_id = input("Remove Subject by ID: ").strip()
        removed = self.student.remove_subject(subject_id)

        if removed:
            print_notice(f"Droping Subject-{subject_id}")
            print_notice(f"You are now enrolled in {len(self.student.subjects)} out of 4 subjects")
            self.save_student()
        else:
            print_error(f"Subject ID {subject_id} not found")

    def show_subjects(self):
        if not self.student.subjects:
            print_notice("No enrolled subjects yet.")
            return

        print_success(f"\n{self.student.name}'s Subjects")
        for subject in self.student.subjects:
            print(subject)
        avg = self.student.average_mark()
        print_notice(f"Average Mark: {avg:.2f}")

    def save_student(self):
        students = Database.load_students()
        for i, s in enumerate(students):
            if s.id == self.student.id:
                students[i] = self.student
                break
        Database.save_students(students)
