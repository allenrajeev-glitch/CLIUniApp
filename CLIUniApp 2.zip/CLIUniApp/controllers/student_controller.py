

from utils.printer import print_prompt, print_success, print_error, print_notice
from utils.validators import is_valid_email, is_valid_password
from models.database import Database
from models.student import Student
from controllers.enrolment_controller import EnrolmentController

class StudentController:
    def show_menu(self):
        while True:
            print()
            print_prompt("Student System (l/r/x): "), 
            choice = input().strip().lower()

            if choice == "l":
                self.login()
            elif choice == "r":
                self.register()
            elif choice == "x":
                break
            else:
                print_error("Invalid input. Please enter 'l', 'r', or 'x'.")

    def register(self):
        print_success("\nStudent Sign Up")
        email = input("Email: ").strip()
        password = input("Password: ").strip()

        if not is_valid_email(email) or not is_valid_password(password):
            print_error("Incorrect email or password format")
            return

        print_notice("email and password formats acceptable")
        name = input("Name: ").strip()

        # Check if student already exists
        if Database.find_student_by_email(email):
            print_error(f"Student {name} already exists")
            return

        student = Student(id=Student.generate_id(), name=name, email=email, password=password)
        students = Database.load_students()
        students.append(student)
        Database.save_students(students)

        print_success(f"Enrolling Student {student.name}")

    def login(self):
        print_success("\nStudent Sign In")
        email = input("Email: ").strip()
        password = input("Password: ").strip()

        if not is_valid_email(email) or not is_valid_password(password):
            print_error("Incorrect email or password format")
            return

        print_notice("email and password formats acceptable")
        student = Database.find_student_by_email(email)

        if not student:
            print_error("Student does not exist")
            return

        if student.password != password:
            print_error("Incorrect password")
            return

        print_success(f"Welcome back, {student.name}!")
        EnrolmentController(student).show_menu()
