

from utils.printer import print_prompt, print_notice, print_error
from controllers.admin_controller import AdminController
from controllers.student_controller import StudentController

class UniversityController:
    def __init__(self):
        self.running = True

    def show_menu(self):
        while self.running:
            print()
            print_prompt("University System:  (A)dmin,  (S)tudent, or X : "), 
            choice = input().strip().upper()

            if choice == "A":
                AdminController().show_menu()
            elif choice == "S":
                StudentController().show_menu()
            elif choice == "X":
                print_notice("Thank You")
                self.running = False
            else:
                print_error("Invalid input. Please enter A, S, or X.")
