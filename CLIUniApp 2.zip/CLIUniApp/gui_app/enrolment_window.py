
import tkinter as tk
from tkinter import messagebox
from models.database import Database
from subject_window import SubjectWindow

class EnrolmentWindow:
    def __init__(self, master, student):
        self.master = master
        self.student = student
        self.master.title("Subject Enrolment")
        self.master.geometry("400x300")

        self.label = tk.Label(master, text=f"Welcome, {student.name}")
        self.label.pack(pady=10)

        self.status_label = tk.Label(master, text=self.get_subject_status())
        self.status_label.pack(pady=5)

        self.enrol_btn = tk.Button(master, text="Enrol in a New Subject", command=self.enrol_subject)
        self.enrol_btn.pack(pady=10)

        self.view_btn = tk.Button(master, text="View Enrolled Subjects", command=self.view_subjects)
        self.view_btn.pack(pady=10)

        self.logout_btn = tk.Button(master, text="Logout", command=self.logout)
        self.logout_btn.pack(pady=20)

    def get_subject_status(self):
        count = len(self.student.subjects)
        return f"You are currently enrolled in {count} out of 4 subjects."

    def enrol_subject(self):
        if len(self.student.subjects) >= 4:
            messagebox.showerror("Enrolment Limit", "Students are allowed to enrol in 4 subjects only.")
            return

        subject = self.student.enrol_subject()
        self.save_student()
        messagebox.showinfo("Enrolment Successful", f"Enrolled in Subject-{subject.subject_id} (Mark: {subject.mark}, Grade: {subject.grade})")
        self.status_label.config(text=self.get_subject_status())

    def view_subjects(self):
        if not self.student.subjects:
            messagebox.showinfo("No Subjects", "You are not enrolled in any subjects.")
        else:
            SubjectWindow(tk.Toplevel(self.master), self.student)

    def logout(self):
        self.master.destroy()

    def save_student(self):
        students = Database.load_students()
        for i, s in enumerate(students):
            if s.id == self.student.id:
                students[i] = self.student
                break
        Database.save_students(students)
