

import tkinter as tk
from login_window import LoginWindow

def launch_gui():
    root = tk.Tk()
    root.title("CLIUniApp - GUI Login")
    root.geometry("400x250")
    app = LoginWindow(root)
    root.mainloop()

if __name__ == "__main__":
    launch_gui()
