

import tkinter as tk
from tkinter import messagebox
from utils.validators import is_valid_email, is_valid_password
from models.database import Database
from enrolment_window import EnrolmentWindow

class LoginWindow:
    def __init__(self, master):
        self.master = master
        self.master.title("Student Login")

        self.email_label = tk.Label(master, text="Email:")
        self.email_label.pack(pady=(20, 5))
        self.email_entry = tk.Entry(master, width=30)
        self.email_entry.pack()

        self.password_label = tk.Label(master, text="Password:")
        self.password_label.pack(pady=(10, 5))
        self.password_entry = tk.Entry(master, width=30, show="*")
        self.password_entry.pack()

        self.login_btn = tk.Button(master, text="Login", command=self.attempt_login)
        self.login_btn.pack(pady=15)

    def attempt_login(self):
        email = self.email_entry.get().strip()
        password = self.password_entry.get().strip()

        if not is_valid_email(email):
            messagebox.showerror("Invalid Email", "Email format is incorrect.\nExpected: name@university.com")
            return
        if not is_valid_password(password):
            messagebox.showerror("Invalid Password", "Password must start with uppercase, have 5+ letters and 3+ digits.")
            return

        student = Database.find_student_by_email(email)
        if student is None:
            messagebox.showerror("Login Failed", "Student does not exist.")
            return
        if student.password != password:
            messagebox.showerror("Login Failed", "Incorrect password.")
            return

        # Login successful
        messagebox.showinfo("Login Success", f"Welcome {student.name}!")
        self.master.withdraw()  # Hide login window
        EnrolmentWindow(tk.Toplevel(self.master), student)
