
import tkinter as tk

class SubjectWindow:
    def __init__(self, master, student):
        self.master = master
        self.student = student
        self.master.title("Your Subjects")
        self.master.geometry("400x300")

        label = tk.Label(master, text=f"{student.name}'s Enrolled Subjects")
        label.pack(pady=10)

        if not student.subjects:
            info = tk.Label(master, text="No subjects enrolled.")
            info.pack()
            return

        for subject in student.subjects:
            subj_text = f"Subject::{subject.subject_id} -- mark = {subject.mark} -- grade = {subject.grade}"
            subj_label = tk.Label(master, text=subj_text, anchor="w", justify="left")
            subj_label.pack(pady=2, anchor="w")
