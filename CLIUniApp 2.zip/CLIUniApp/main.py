
from controllers.university_controller import UniversityController
from utils.printer import print_success

def main():
    print_success("Welcome to CLIUniApp – University Enrollment System")
    controller = UniversityController()
    controller.show_menu()

if __name__ == "__main__":
    main()
