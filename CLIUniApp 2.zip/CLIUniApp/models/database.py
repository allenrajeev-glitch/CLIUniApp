

import os
import json
from models.student import Student

STUDENT_FILE = "students.data"

class Database:

    @staticmethod
    def ensure_file():
        """Ensure the students.data file exists."""
        if not os.path.exists(STUDENT_FILE):
            with open(STUDENT_FILE, "w") as f:
                json.dump([], f)

    @staticmethod
    def load_students():
        """Loads and returns a list of Student objects from file."""
        Database.ensure_file()
        with open(STUDENT_FILE, "r") as f:
            data = json.load(f)
            return [Student.from_dict(item) for item in data]

    @staticmethod
    def save_students(students):
        """Saves list of Student objects to file."""
        with open(STUDENT_FILE, "w") as f:
            json.dump([student.to_dict() for student in students], f, indent=2)

    @staticmethod
    def find_student_by_email(email):
        """Returns student with matching email or None."""
        students = Database.load_students()
        for student in students:
            if student.email == email:
                return student
        return None

    @staticmethod
    def delete_student_by_id(student_id):
        """Deletes student by ID and returns True if successful."""
        students = Database.load_students()
        updated = [s for s in students if s.id != student_id]
        if len(updated) != len(students):
            Database.save_students(updated)
            return True
        return False

    @staticmethod
    def clear_all():
        """Deletes all student records."""
        with open(STUDENT_FILE, "w") as f:
            json.dump([], f)
