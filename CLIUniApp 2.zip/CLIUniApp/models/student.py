

import random
from models.subject import Subject

class Student:
    def __init__(self, id, name, email, password, subjects=None):
        self.id = id or self.generate_id()
        self.name = name
        self.email = email
        self.password = password
        self.subjects = subjects or []

    @staticmethod
    def generate_id():
        """Generate a 6-digit zero-padded student ID"""
        return str(random.randint(1, 999999)).zfill(6)

    def enrol_subject(self):
        """Add a new subject if enrolment limit not reached"""
        if len(self.subjects) >= 4:
            return False
        subject = Subject()
        self.subjects.append(subject)
        return subject

    def remove_subject(self, subject_id):
        """Remove subject by ID if it exists"""
        for s in self.subjects:
            if s.subject_id == subject_id:
                self.subjects.remove(s)
                return True
        return False

    def change_password(self, new_password):
        """Update the password"""
        self.password = new_password

    def average_mark(self):
        """Calculate average mark of enrolled subjects"""
        if not self.subjects:
            return 0.0
        return sum(s.mark for s in self.subjects) / len(self.subjects)

    def is_pass(self):
        """Returns True if average mark >= 50"""
        return self.average_mark() >= 50

    def to_dict(self):
        """Convert object to serializable format"""
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "password": self.password,
            "subjects": [s.to_dict() for s in self.subjects]
        }

    @classmethod
    def from_dict(cls, data):
        """Recreate a Student object from dictionary"""
        subjects = [Subject.from_dict(s) for s in data.get("subjects", [])]
        return cls(
            id=data["id"],
            name=data["name"],
            email=data["email"],
            password=data["password"],
            subjects=subjects
        )

    def __str__(self):
        return f"{self.name} :: {self.id} --> Email: {self.email}"

    def get_subject_summary(self):
        """Print list of enrolled subjects"""
        return "\n".join(str(s) for s in self.subjects)
