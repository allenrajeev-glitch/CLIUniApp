
import random

class Subject:
    def __init__(self, subject_id=None, mark=None, grade=None):
        self.subject_id = subject_id or self.generate_id()
        self.mark = mark or self.generate_mark()
        self.grade = grade or self.assign_grade(self.mark)

    def generate_id(self):
        """Generates a 3-digit subject ID"""
        return str(random.randint(1, 999)).zfill(3)

    def generate_mark(self):
        """Generates a mark between 25 and 100"""
        return random.randint(25, 100)

    def assign_grade(self, mark):
        """Assigns a grade based on the mark"""
        if mark < 50:
            return 'Z'
        elif mark < 65:
            return 'P'
        elif mark < 75:
            return 'C'
        elif mark < 85:
            return 'D'
        else:
            return 'HD'

    def to_dict(self):
        """Convert Subject object to dictionary for saving"""
        return {
            "subject_id": self.subject_id,
            "mark": self.mark,
            "grade": self.grade
        }

    @classmethod
    def from_dict(cls, data):
        """Create a Subject object from dictionary"""
        return cls(
            subject_id=data["subject_id"],
            mark=data["mark"],
            grade=data["grade"]
        )

    def __str__(self):
        return f"[ Subject::{self.subject_id} -- mark = {self.mark} -- grade = {self.grade} ]"
