
from colorama import Fore, Style, init

# Initialize colorama for Windows compatibility
init(autoreset=True)

def print_success(message):
    """Prints a message in green."""
    print(Fore.GREEN + message)

def print_error(message):
    """Prints a message in red."""
    print(Fore.RED + message)

def print_notice(message):
    """Prints a message in yellow (for warnings/info)."""
    print(Fore.YELLOW + message)

def print_prompt(message):
    """Prints a message in cyan (for CLI input prompts)."""
    print(Fore.CYAN + message)

def print_plain(message):
    """Prints plain white message (fallback/default)."""
    print(Style.RESET_ALL + message)
