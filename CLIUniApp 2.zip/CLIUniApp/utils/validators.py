import re

# Must end in @university.com, allow dots in local part
EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.university\.com$')

# Starts with capital letter, 5+ letters total, then 3+ digits (only letters before digits)
PASSWORD_PATTERN = re.compile(r'^[A-Z][a-zA-Z]{4,}[0-9]{3,}$')

def is_valid_email(email: str) -> bool:
    match = EMAIL_PATTERN.match(email)
    print("EMAIL MATCHED:", bool(match))  # TEMPORARY DEBUG
    return bool(match)

def is_valid_password(password: str) -> bool:
    match = PASSWORD_PATTERN.match(password)
    print("PASSWORD MATCHED:", bool(match))  # TEMPORARY DEBUG
    return bool(match)
